#include <iostream>
using namespace std;
#include <stdlib.h>
#include <GL/glut.h>
#include "glm.h"
#include <math.h>
#include"imageloader.h"

#define PI 3.14

double eye[] = {0.0, 0.0, 10};
double center[] = {0.0, 0.0, 0.0};
double up[] = {0.0, 1.0, 0.0};

static int shoulder = 0, elbow = 0, arm=0, joint=0;

static int left_hip = 0, left_thigh = 0, left_leg = 0,
	       right_hip = 0, right_thigh = 0, right_leg = 0;
int moving, startx, starty;


GLfloat angle = 0.0;   
GLfloat angle2 = 0.0;   

// Animation Poses
float poses[180][14] = {  // Passing Soccerball
						{0,0,0,0,0,0,10,0,0,0,0,0,0,0}, {0,0,0,0,0,0,20,0,0,0,0,0,0,0}, {0,0,0,0,0,0,30,0,0,0,0,0,0,0}, {0,0,0,0,0,5,30,0,0,0,0,0,0,0},
						{0,0,0,0,0,5,40,0,0,0,0,0,0,0}, {0,0,0,0,0,10,40,0,0,0,0,0,0,0}, {0,0,0,0,0,10,50,0,0,0,0,0,0,0}, {0,0,0,0,0,15,50,0,0,0,0,0,0,0},
						{0,0,0,0,0,15,60,0,0,0,0,0,0,0}, {0,0,0,0,0,20,60,0,0,0,0,0,0,0}, {0,0,0,0,0,25,60,0,0,0,0,0,0,0}, {0,0,0,0,0,15,60,0,0,0,0,0,0,0},
						{0,0,0,0,0,15,50,0,0,0,0,0,0,0}, {0,0,0,0,0,10,50,0,0,0,0,0,0,0}, {0,0,0,0,0,10,40,0,0,0,0,0,0,0}, {0,0,0,0,0,5,40,0,0,0,0,0,0,0},
						{0,0,0,0,0,5,30,0,0,0,0,0,0}, {0,0,0,0,0,5,20,0,0,0,0,0,0}, {0,0,0,0,0,0,20,0,0,0,0,0,0,0}, {0,0,0,0,0,0,10,0,0,0,0,0,0,0},
						{0,0,0,0,0,0,0,0,0,0,0.1,0.1,0,0}, {0,0,0,0,0,-5,0,0,0,0,0.3,0.3,0}, {0,0,0,0,0,-10,0,0,0,0,0.5,0.5,0}, {0,0,0,0,0,-15,0,0,0,0,0.8,0.8,0,0},
						{0,0,0,0,0,-25,0,0,0,0,1,1,0,0}, {0,0,0,0,0,-35,0,0,0,0,1.3,1.3,0,0}, {0,0,0,0,0,-45,0,0,0,0,1.6,1.6,0,0}, {0,0,0,0,0,-40,0,0,0,0,2,2,0,0},
						{0,0,0,0,0,-35,0,0,0,0,2.3,2.3,0,0}, {0,0,0,0,0,-30,0,0,0,0,2.1,2.5,0,0}, {0,0,0,0,0,-25,0,0,0,0,1.8,2.8,0,0}, {0,0,0,0,0,-15,0,0,0,0,1.5,3.1,0,0},
						{0,0,0,0,0,-10,0,0,0,0,1.2,3.4,0,0}, {0,0,0,0,0,-5,0,0,0,0,0.8,3.8,0,0}, {0,0,0,0,0,0,0,0,0,0,0.3,4.3,0,0}, {0,0,0,0,0,0,0,0,0,0,0,4.7,0,0},

                          // Raising Arms
						{10,0,5,0,0,0,0,0,0,0,0,4.7,0,0}, {20,0,10,0,0,0,0,0,0,0,0,4.7,0,0},
						{30,0,15,0,0,0,0,0,0,0,0,4.7,0,0}, {40,0,20,0,0,0,0,0,0,0,0,4.7,0,0},
						{50,0,25,0,0,0,0,0,0,0,0,4.7,0,0}, {60,0,30,0,0,0,0,0,0,0,0,4.7,0,0},
						{70,0,35,0,0,0,0,0,0,0,0,4.7,0,0}, {80,0,40,0,0,0,0,0,0,0,0,4.7,0,0},
						{90,0,45,0,0,0,0,0,0,0,0,4.7,0,0}, {100,0,50,0,0,0,0,0,0,0,0,4.7,0,0},
						{110,0,55,0,0,0,0,0,0,0,0,4.7,0,0}, {120,0,60,0,0,0,0,0,0,0,0,4.7,0,0},
						{130,0,65,0,0,0,0,0,0,0,0,4.7,0,0}, {140,0,70,0,0,0,0,0,0,0,0,4.7,0,0},
						{150,0,75,0,0,0,0,0,0,0,0,4.7,0,0}, {160,0,80,0,0,0,0,0,0,0,0,4.7,0,0},

						  // Raising Hat & Lowering Arms
						{160,0,75,0,0,0,0,0,0,0,0,4.7,-0.1,0}, {160,0,70,0,0,0,0,0,0,0,0,4.7,-0.2,0}, {160,0,65,0,0,0,0,0,0,0,0,4.7,-0.3,0}, {160,0,70,0,0,0,0,0,0,0,0,4.7,-0.2,0},
						{160,0,75,0,0,0,0,0,0,0,0,4.7,-0.1,0}, {160,0,80,0,0,0,0,0,0,0,0,4.7,0,0}, {150,0,75,0,0,0,0,0,0,0,0,4.7,0,0}, {140,0,70,0,0,0,0,0,0,0,0,4.7,0,0},
						{130,0,65,0,0,0,0,0,0,0,0,4.7,0,0}, {120,0,60,0,0,0,0,0,0,0,0,4.7,0,0}, {110,0,55,0,0,0,0,0,0,0,0,4.7,0,0}, {100,0,50,0,0,0,0,0,0,0,0,4.7,0,0},
						{90,0,45,0,0,0,0,0,0,0,0,4.7,0,0}, {80,0,40,0,0,0,0,0,0,0,0,4.7,0,0}, {70,0,35,0,0,0,0,0,0,0,0,4.7,0,0}, {60,0,30,0,0,0,0,0,0,0,0,4.7,0,0},
						{50,0,25,0,0,0,0,0,0,0,0,4.7,0,0}, {40,0,20,0,0,0,0,0,0,0,0,4.7,0,0}, {30,0,15,0,0,0,0,0,0,0,0,4.7,0,0}, {20,0,10,0,0,0,0,0,0,0,0,4.7,0,0},
						{10,0,5,0,0,0,0,0,0,0,0,4.7,0,0}, {0,0,0,0,0,0,0,0,0,0,0,4.7,0,0},

						  // Walking Step-by-step
						{0,0,0,0,0,0,5,0,0,0,0,4.7,0,0}, {0,0,0,0,0,0,10,0,0,0,0,4.7,0,0}, {0,0,0,0,0,0,15,0,0,0,0,4.7,0,0}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,0},          // raising left leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,0.15}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0.15}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0.15}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,0.15},  // raising left thigh & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,0.15}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,0.15}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,0.15}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,0.15}, // lowering left thigh & leg

						{0,0,0,0,0,0,5,0,-5,20,0,4.7,0,0.3}, {0,0,0,0,0,0,10,0,-10,20,0,4.7,0,0.3}, {0,0,0,0,0,0,15,0,-15,20,0,4.7,0,0.3}, {0,0,0,0,0,0,20,0,-20,20,0,4.7,0,0.3},  // raising right thigh (righ leg already raised) & left leg
						{0,0,0,0,0,0,20,0,-15,15,0,4.7,0,0.3}, {0,0,0,0,0,0,20,0,-10,10,0,4.7,0,0.3}, {0,0,0,0,0,0,20,0,-5,5,0,4.7,0,0.3}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,0.3},   // lowering right thigh & leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,0.45}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0,0.45}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0,0.45}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,0.45},   // raising left thigh (left leg already raised) & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,0.45}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,0.45}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,0.45}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,0.45},  // lowering left thigh & leg

						{0,0,0,0,0,0,5,0,-5,20,0,4.7,0,0.6}, {0,0,0,0,0,0,10,0,-10,20,0,4.7,0,0.6}, {0,0,0,0,0,0,15,0,-15,20,0,4.7,0,0.6}, {0,0,0,0,0,0,20,0,-20,20,0,4.7,0,0.6},  // raising right thigh (righ leg already raised) & left leg
						{0,0,0,0,0,0,20,0,-15,15,0,4.7,0,0.6}, {0,0,0,0,0,0,20,0,-10,10,0,4.7,0,0.6}, {0,0,0,0,0,0,20,0,-5,5,0,4.7,0,0.6}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,0.6},   // lowering right thigh & leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,0.75}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0,0.75}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0,0.75}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,0.75},   // raising left thigh (left leg already raised) & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,0.75}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,0.75}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,0.75}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,0.75},  // lowering left thigh & leg

						{0,0,0,0,0,0,5,0,-5,20,0,4.7,0,0.9}, {0,0,0,0,0,0,10,0,-10,20,0,4.7,0,0.9}, {0,0,0,0,0,0,15,0,-15,20,0,4.7,0,0.9}, {0,0,0,0,0,0,20,0,-20,20,0,4.7,0,0.9},  // raising right thigh (righ leg already raised) & left leg
						{0,0,0,0,0,0,20,0,-15,15,0,4.7,0,0.9}, {0,0,0,0,0,0,20,0,-10,10,0,4.7,0,0.9}, {0,0,0,0,0,0,20,0,-5,5,0,4.7,0,0.9}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,0.9},   // lowering right thigh & leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,1.05}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0,1.05}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0,1.05}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,1.05},   // raising left thigh (left leg already raised) & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,1.05}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,1.05}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,1.05}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,1.05},  // lowering left thigh & leg

						{0,0,0,0,0,0,5,0,-5,20,0,4.7,0,1.2}, {0,0,0,0,0,0,10,0,-10,20,0,4.7,0,1.2}, {0,0,0,0,0,0,15,0,-15,20,0,4.7,0,1.2}, {0,0,0,0,0,0,20,0,-20,20,0,4.7,0,1.2},  // raising right thigh (righ leg already raised) & left leg
						{0,0,0,0,0,0,20,0,-15,15,0,4.7,0,1.2}, {0,0,0,0,0,0,20,0,-10,10,0,4.7,0,1.2}, {0,0,0,0,0,0,20,0,-5,5,0,4.7,0,1.2}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,1.2},     // lowering right thigh & leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,1.35}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0,1.35}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0,1.35}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,1.35},   // raising left thigh (left leg already raised) & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,1.35}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,1.35}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,1.35}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,1.35},     // lowering left thigh & leg

						{0,0,0,0,0,0,5,0,-5,20,0,4.7,0,1.5}, {0,0,0,0,0,0,10,0,-10,20,0,4.7,0,1.5}, {0,0,0,0,0,0,15,0,-15,20,0,4.7,0,1.5}, {0,0,0,0,0,0,20,0,-20,20,0,4.7,0,1.5},  // raising right thigh (righ leg already raised) & left leg
						{0,0,0,0,0,0,20,0,-15,15,0,4.7,0,1.5}, {0,0,0,0,0,0,20,0,-10,10,0,4.7,0,1.5}, {0,0,0,0,0,0,20,0,-5,5,0,4.7,0,1.5}, {0,0,0,0,0,0,20,0,0,0,0,4.7,0,1.5},   // lowering right thigh & leg

						{0,0,0,0,0,-5,20,0,0,5,0,4.7,0,1.65}, {0,0,0,0,0,-10,20,0,0,10,0,4.7,0,1.65}, {0,0,0,0,0,-15,20,0,0,15,0,4.7,0,1.65}, {0,0,0,0,0,-20,20,0,0,20,0,4.7,0,1.65},   // raising left thigh (left leg already raised) & right leg
						{0,0,0,0,0,-15,15,0,0,20,0,4.7,0,1.65}, {0,0,0,0,0,-10,10,0,0,20,0,4.7,0,1.65}, {0,0,0,0,0,-5,5,0,0,20,0,4.7,0,1.65}, {0,0,0,0,0,0,0,0,0,20,0,4.7,0,1.65},     // lowering left thigh & leg

						 {0,0,0,0,0,0,0,0,0,15,0,4.7,0,1.8}, {0,0,0,0,0,0,0,0,0,10,0,4.7,0,1.8}, {0,0,0,0,0,0,0,0,0,5,0,4.7,0,1.8},{0,0,0,0,0,0,0,0,0,0,0,4.7,0,1.8} };  // lowering right leg

// Passing Ball Animation Parameters			
const char *soccerball = "data/soccerball.obj";
const char *football_goal = "data/football-goal.obj";
float ball_position_y = 0, ball_position_z = 0;

// Raising Hat Animation Parameters
const char *casquette = "data/casquette.obj";
float casquette_position_y = 0;

// Walking Animation Parameters
float step_forward = 0;

// Initial Texture Mapping Image
const char* imagename = "images/grass.bmp";

// Lighting
GLfloat light_ambient[] = {0.0, 0.0, 0.0, 0.0};
GLfloat light_diffuse[] = {1.0, 1.0, 1.0, 1.0};
GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};
GLfloat light0_position[] = {0, 0 , 2.0, 1.0};

// Drawing Model Function
void drawmodel(char *filename)
{
	GLMmodel *model = glmReadOBJ(filename);
	glmUnitize(model);
	glmFacetNormals(model);
	glmVertexNormals(model, 90.0);
	glmScale(model, .15);
	glmDraw(model, GLM_SMOOTH | GLM_MATERIAL);
}

void init(void)
{
   glClearColor(0.0, 0.0, 0.0, 0.0);   
   glShadeModel(GL_FLAT);             
}

// Loading Texture Function
GLuint loadTexture(Image* image)
{
	GLuint textureId;
	glGenTextures(1, &textureId);			 
	glBindTexture(GL_TEXTURE_2D, textureId); 
	
	glTexImage2D(GL_TEXTURE_2D,				
		0,							 
		GL_RGB,					 
		image->width, image->height, 
		0,							
		GL_RGB,					 
		GL_UNSIGNED_BYTE,			  
									
		image->pixels);			 
	return textureId;						 
}

// ID of Texture
GLuint _textureId;

//Initializing 3D Rendering
void LoadImage()
{
	Image* image = loadBMP((char*)imagename);
	_textureId = loadTexture(image);
	delete image;
	glEnable(GL_NORMALIZE);
	//Enable smooth shading
	glShadeModel(GL_SMOOTH);
	// Enable Depth buffer
	glEnable(GL_DEPTH_TEST);
}

void drawShoulderAndArm(float x, float y, float armAngle)
{
	 glPushMatrix();

	  //Draw shoulder

      glTranslatef (x, y, 0.0);
	  glRotatef (-90, 0.0, 0.0, 1.0);
	  glRotatef ((GLfloat) shoulder, 0.0, 0.0, 1.0);
	  glRotatef ((GLfloat) armAngle, 1.0, 0.0, 0.0);
      glTranslatef (1.0*0.5, 0.0, 0.0);

      glPushMatrix();
         glScalef (2.0*0.5, 0.6*0.5, 1.0*0.5);
         glutWireCube (1.0);
      glPopMatrix();

   //Draw elbow 

      glTranslatef (1.0*0.5, 0.0, 0.0);
      glRotatef ((GLfloat) elbow, 0.0, 0.0, 1.0);
	  glRotatef ((GLfloat) joint, 0.0, 1.0, 0.0);
      glTranslatef (1.0*0.5, 0.0, 0.0);

      glPushMatrix();
         glScalef (2.0*0.5, 0.6*0.5, 1.0*0.5);
         glutWireCube (1.0);
      glPopMatrix();

if ( armAngle == - arm )
{ glRotatef(180, 1, 0, 0); }

	//Draw finger flang 1 

   glPushMatrix();
      
      glTranslatef(1.15*0.5, 0.0, -0.39*0.5);                        

      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);
      glPopMatrix();


   //Draw finger flang 1 

      glTranslatef(0.3*0.5, 0.0, 0.0);
   
      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);         
      glPopMatrix();
   glPopMatrix();

   //Draw finger flang 2 

   glPushMatrix();
      
      glTranslatef(1.15*0.5, 0.0, -0.23*0.5);                    

      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);
      glPopMatrix();


   //Draw finger flang 2 
      
      glTranslatef(0.3*0.5, 0.0, 0.0);
   
      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);         
      glPopMatrix();
   glPopMatrix();

   //Draw finger flang 3 .

   glPushMatrix();
      
      glTranslatef(1.15*0.5, 0.0, -0.07*0.5);                  

      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);
      glPopMatrix();


   //Draw finger flang 3 
     
      glTranslatef(0.3*0.5, 0.0, 0.0);
   
      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);         
      glPopMatrix();
   glPopMatrix();

   //Draw finger flang 4 

   glPushMatrix();
     
      glTranslatef(1.15*0.5, 0.0, 0.09*0.5);                  

      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);
      glPopMatrix();


   //Draw finger flang 4 
      
      glTranslatef(0.3*0.5, 0.0, 0.0);
   
      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);       
      glPopMatrix();
   glPopMatrix();
   
   //Draw finger flang 5 

   glPushMatrix();
     
      glTranslatef(1.15*0.5, 0.0, 0.38*0.5);               

      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);
      glPopMatrix();


   //Draw finger flang 5 
      
      glTranslatef(0.3*0.5, 0.0, 0.0);
   
      glPushMatrix();
         glScalef(0.3*0.5, 0.1*0.5, 0.1*0.5);
         glutWireCube(1);         
      glPopMatrix();
   glPopMatrix();

   glPopMatrix();
}

void drawHipAndLeg(float hip, float thigh, float leg, float x, float y)
{
	glPushMatrix();

	//Draw Hip
   
      glTranslatef (x, y, 0);
	  glRotatef ((GLfloat) hip, 0.0, 0.0, 1.0);
	  glRotatef ((GLfloat) thigh, 1.0, 0.0, 0.0);
      glTranslatef (0.0, -1.875/2, 0.0);

      glPushMatrix();
         glScalef (1*0.5, 3.75*0.5, 1*0.5);
         glutWireCube (1.0);
      glPopMatrix();

   //Draw Leg 

      glTranslatef (0.0, -1.875/2, 0.0);
      glRotatef ((GLfloat) leg, 1.0, 0.0, 0.0);
      glTranslatef (0.0, -1.875/2, 0.0);

      glPushMatrix();
         glScalef (1*0.5, 3.75*0.5, 1*0.5);
         glutWireCube (1.0);
      glPopMatrix();

	// Draw Foot

      glTranslatef (0.0, -1.875/2-0.25, 0.0);

	  glPushMatrix();
		 glScalef (1*0.5, 1.5/3, 4*0.5);
		 glutSolidCube(1);
	  glPopMatrix();

	glPopMatrix();
}

// Play Ball Animation Function
void playBall( float y, float z )
{
   glPushMatrix();
   glTranslatef(0.5,-3.5 + y, 1.5 + z);
   glScalef(5, 5, 5);
   drawmodel((char * )soccerball);
   glPopMatrix();
}

// Raising Hat Animation Function
void raiseCasquette( float y )
{ 
   glPushMatrix();
   glTranslatef(0,3.1 - y,0.2);
   glScalef(5, 5, 5);
   drawmodel((char * )casquette);
   glPopMatrix();
}

// Walking Animation Function
void walk( float z)
{
	glTranslatef(0,0,z);
}

// Drawing Football Goal Object
void drawFootBallGoal()
{
   glPushMatrix();
   glTranslatef(0,-1.3,6);
   glRotatef(180,0,1,0);
   glScalef(25,25,25);
   drawmodel((char * )football_goal);
   glPopMatrix();
}

// Drawing Floor (Texture Mapping)
void drawFoor()
{
	glPushMatrix();
	glTranslatef(0, 1.85, -1.0);
	glRotatef(90,0,1,0);
	LoadImage();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBegin(GL_QUADS);
	glNormal3f(0.0, 1.0, 0.0);
	glTexCoord2f(0.0f, 0.0f); glVertex3f(-10, -6, 5);
	glTexCoord2f(3.0f, 0.0f); glVertex3f(10, -6, 5);
	glTexCoord2f(3.0f, 3.0f); glVertex3f(10, -6, -5);
	glTexCoord2f(0.0f, 3.0f); glVertex3f(-10, -6, -5);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();

}

void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
   gluLookAt(eye[0], eye[1], eye[2],
			  center[0], center[1], center[2],
			  up[0], up[1], up[2]);

   glRotatef(angle2, 1.0, 0.0, 0.0);  
   glRotatef(angle, 0.0, 1.0, 0.0);    

   glRotatef(20,1,0,0);
   glRotatef(-130,0,1,0);

   drawFoor();

   drawFootBallGoal();

   playBall(ball_position_y, ball_position_z );

   walk(step_forward);

   // Drawing and Transformations

   glTranslatef(0,2,0);

   drawHipAndLeg(right_hip, right_thigh, right_leg, -0.5, -1.875);
   drawHipAndLeg(left_hip, left_thigh, left_leg, 0.5, -1.875);
	
   glPushMatrix();
       glTranslatef(-1.1,1.6,0);
	   glRotatef(180, 0, 1, 0);
	   drawShoulderAndArm(0, 0, -arm);
   glPopMatrix();
	drawShoulderAndArm(1.1, 1.6, arm);

   glPushMatrix();
       glTranslatef(0,2.7,0);
	   glutWireSphere(0.5,15,15);
   glPopMatrix();

	raiseCasquette(casquette_position_y);
   
   glScalef(1.5, 3.75, 0.5);
   glutWireCube(1);

   glutSwapBuffers();
}


void reshape(int w, int h)           
{
   glViewport(0, 0, (GLsizei)w, (GLsizei)h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(85.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glTranslatef(0.0, 0.0, -5.0);
}

void rotatePoint(double a[], double theta, double p[])
{

	double temp[3];
	temp[0] = p[0];
	temp[1] = p[1];
	temp[2] = p[2];

	temp[0] = -a[2] * p[1] + a[1] * p[2];
	temp[1] = a[2] * p[0] - a[0] * p[2];
	temp[2] = -a[1] * p[0] + a[0] * p[1];

	temp[0] *= sin(theta);
	temp[1] *= sin(theta);
	temp[2] *= sin(theta);

	temp[0] += (1 - cos(theta)) * (a[0] * a[0] * p[0] + a[0] * a[1] * p[1] + a[0] * a[2] * p[2]);
	temp[1] += (1 - cos(theta)) * (a[0] * a[1] * p[0] + a[1] * a[1] * p[1] + a[1] * a[2] * p[2]);
	temp[2] += (1 - cos(theta)) * (a[0] * a[2] * p[0] + a[1] * a[2] * p[1] + a[2] * a[2] * p[2]);

	temp[0] += cos(theta) * p[0];
	temp[1] += cos(theta) * p[1];
	temp[2] += cos(theta) * p[2];

	p[0] = temp[0];
	p[1] = temp[1];
	p[2] = temp[2];
}

void crossProduct(double a[], double b[], double c[])
{
	c[0] = a[1] * b[2] - a[2] * b[1];
	c[1] = a[2] * b[0] - a[0] * b[2];
	c[2] = a[0] * b[1] - a[1] * b[0];
}

void normalize(double a[])
{
	double norm;
	norm = a[0] * a[0] + a[1] * a[1] + a[2] * a[2];
	norm = sqrt(norm);
	a[0] /= norm;
	a[1] /= norm;
	a[2] /= norm;
}

// Rotation about vertical direction
void lookRight()
{
	rotatePoint(up, PI / 8, eye);
}

void lookLeft()
{
	rotatePoint(up, -PI / 8, eye);
}

// Rotation about horizontal direction

void lookUp()
{
	double horizontal[3];
	double look[] = {center[0] - eye[0], center[1] - eye[1], center[2] - eye[2]};
	crossProduct(up, look, horizontal);
	normalize(horizontal);
	rotatePoint(horizontal, PI / 8, eye);
	rotatePoint(horizontal, PI / 8, up);
}

void lookDown()
{
	double horizontal[3];
	double look[] = {center[0] - eye[0], center[1] - eye[1], center[2] - eye[2]};
	crossProduct(up, look, horizontal);
	normalize(horizontal);
	rotatePoint(horizontal, -PI / 8, eye);
	rotatePoint(horizontal, -PI / 8, up);
}

// Forward and Backward
void moveForward()
{
	double direction[3];
	direction[0] = center[0] - eye[0];
	direction[1] = center[1] - eye[1];
	direction[2] = center[2] - eye[2];
	float speed = 0.1;
	eye[0] += direction[0] * speed;
	eye[1] += direction[1] * speed;
	eye[2] += direction[2] * speed;

	center[0] += direction[0] * speed;
	center[1] += direction[1] * speed;
	center[2] += direction[2] * speed;
}

void moveBackward()
{
	double direction[3];
	direction[0] = center[0] - eye[0];
	direction[1] = center[1] - eye[1];
	direction[2] = center[2] - eye[2];
	float speed = -0.1;
	eye[0] += direction[0] * speed;
	eye[1] += direction[1] * speed;
	eye[2] += direction[2] * speed;

	center[0] += direction[0] * speed;
	center[1] += direction[1] * speed;
	center[2] += direction[2] * speed;
}

void reset()
{
	double e[] = {0.0, 0.0, 10.0};
	double c[] = {0.0, 0.0, 0.0};
	double u[] = {0.0, 1.0, 0.0};
	for (int i = 0; i < 3; i++)
	{
		eye[i] = e[i];
		center[i] = c[i];
		up[i] = u[i];
	}
}

void screen_menu(int value)
{
	switch (value)
	{
	case '1':
		imagename = "images/marble.bmp";
		break;
	case '2':
		imagename = "images/wood.bmp";
		break;
	case '3':
		imagename = "images/ice.bmp";
		break;
	case '4':
		imagename = "images/stones.bmp";
		break;
	case '5':
		imagename = "images/grass.bmp";
		break;
	}
	reset();
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
   switch (key)
   {

	 case 'p':
	  cout << "shoulder: " << shoulder << endl;
	  cout << "arm: " << arm << endl;
	  cout << "elbow: " << elbow << endl;
	  cout << "joint: " << joint << endl;
	  cout << "left_hip: " << left_hip << endl;
	  cout << "left_thigh: " << left_thigh << endl;
	  cout << "left_leg: " << left_leg << endl;
	  cout << "right_hip: " << right_hip << endl;
	  cout << "right_thigh: " << right_thigh << endl;
	  cout << "right_leg: " << right_leg << endl;
	  cout << "ball_position_y: " << ball_position_y << endl;
	  cout << "ball_position_z: " << ball_position_z << endl;
	  cout << "casquette_position_y: " << casquette_position_y << endl;
	  cout << "step_forward: " << step_forward << endl << endl;
	  glutPostRedisplay();
	  break;
	  
	case 'u':
	  ball_position_y = ( ball_position_y + 0.1 );
	  ball_position_z = ( ball_position_z + 0.1 );
      glutPostRedisplay();
      break;
	case 'd':
	  ball_position_y = ( ball_position_y - 0.1 );
	  ball_position_z = ( ball_position_z + 0.1 );
      glutPostRedisplay();
      break;

	case 'c':
	  casquette_position_y = ( casquette_position_y - 0.1 );
      glutPostRedisplay();
      break;
	case 'C':
	  casquette_position_y = ( casquette_position_y + 0.1 );
      glutPostRedisplay();
      break;

	case 'o':
	  step_forward = ( step_forward + 0.1 );
      glutPostRedisplay();
      break;

	// Shoulder Controls

   case 's':
      shoulder = (shoulder + 5);
	  if ( shoulder > 170 )
	  { shoulder = (shoulder - 5); }
      glutPostRedisplay();
      break;
   case 'S':
      shoulder = (shoulder - 5);
	  if ( shoulder < 0 )
	  { shoulder = (shoulder + 5); }
      glutPostRedisplay();
      break;
   case 'a':
      arm = ( arm + 5);
	  if ( arm > 90 )
	  { arm = (arm - 5); }
      glutPostRedisplay();
      break;
   case 'A':
      arm = (arm - 5);
	  if ( arm < -180 )
	  { arm = (arm + 5); }
      glutPostRedisplay();
      break;

   // Elbow Controls

   case 'e':
      elbow = (elbow + 5);
	  if ( elbow > 150 )
	  { elbow = (elbow - 5); }
	  glutPostRedisplay();
      break;
   case 'E':
      elbow = (elbow - 5);
	  if ( elbow < -80 )
	  { elbow = (elbow + 5); }
	  glutPostRedisplay();
      break;
   case 'j':
      joint = (joint + 5);
	  if ( joint > 70 )
	  { joint = (joint - 5); }
	  glutPostRedisplay();
      break;
   case 'J':
      joint = (joint - 5);
	  if ( joint < -150 )
	  { joint = (joint + 5); }
	  glutPostRedisplay();
      break;

   // Left Hip Controls

   case 'h':
      left_hip = (left_hip + 5);
	  if ( left_hip > 80 )
	  { left_hip = (left_hip - 5); }
	  glutPostRedisplay();
      break;
   case 'H':
      left_hip = (left_hip - 5);
	  if ( left_hip < 0 )
	  { left_hip = (left_hip + 5); }
	  glutPostRedisplay();
      break;
   case 't':
      left_thigh = (left_thigh + 5);
	  if ( left_thigh > 50 )
	  { left_thigh = (left_thigh - 5); }
	  glutPostRedisplay();
      break;
   case 'T':
      left_thigh = (left_thigh - 5);
	  if ( left_thigh < -70 )
	  { left_thigh = (left_thigh + 5); }
	  glutPostRedisplay();
      break;

   // Right Hip Controls

   case 'x':
      right_hip = (right_hip + 5);
	  if ( right_hip > 0 )
	  { right_hip = (right_hip - 5); }
	  glutPostRedisplay();
      break;
   case 'X':
      right_hip = (right_hip - 5);
	  if ( right_hip < -80 )
	  { right_hip = (right_hip + 5); }
	  glutPostRedisplay();
      break;
   case 'y':
      right_thigh = (right_thigh + 5);
	  if ( right_thigh > 50 )
	  { right_thigh = (right_thigh - 5); }
	  glutPostRedisplay();
      break;
   case 'Y':
      right_thigh = (right_thigh - 5);
	  if ( right_thigh < -70 )
	  { right_thigh = (right_thigh + 5); }
	  glutPostRedisplay();
      break;

   // Left Leg Controls
   
   case 'l':
      left_leg = (left_leg + 5);
	  if ( left_leg > 100 )
	  { left_leg = (left_leg - 5); }
	  glutPostRedisplay();
      break;
   case 'L':
      left_leg = (left_leg - 5);
	  if ( left_leg < 0 )
	  { left_leg = (left_leg + 5); }
	  glutPostRedisplay();
      break;

   // Right Leg Controls
   
   case 'z':
      right_leg = (right_leg + 5);
	  if ( right_leg > 100 )
	  { right_leg = (right_leg - 5); }
	  glutPostRedisplay();
      break;
   case 'Z':
      right_leg = (right_leg - 5);
	  if ( right_leg < 0 )
	  { right_leg = (right_leg + 5); }
	  glutPostRedisplay();
      break;

   case 'f':
	  moveForward();
	  glutPostRedisplay();
	  break;
   case 'b':
	  moveBackward();
	  glutPostRedisplay();
	  break;
   case 'r':
	  reset();
	  glutPostRedisplay();
	  break;
   case 27:
      exit(0);
      break;
   default:
      break;
   }
}

void attachMenu()
{
	glutCreateMenu(screen_menu);
	glutAddMenuEntry("Floor", 0);
	glutAddMenuEntry("", 0);
	glutAddMenuEntry("Marble", '1');
	glutAddMenuEntry("Wood", '2');
	glutAddMenuEntry("Ice", '3');
	glutAddMenuEntry("Stones", '4');
	glutAddMenuEntry("Grass", '5');
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void specialKeys(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_LEFT:
		lookLeft();
		break;
	case GLUT_KEY_RIGHT:
		lookRight();
		break;
	case GLUT_KEY_UP:
		lookUp();
		break;
	case GLUT_KEY_DOWN:
		lookDown();
		break;
	}
	glutPostRedisplay();
}

static void mouse(int button, int state, int x, int y)
{
  if (button == GLUT_LEFT_BUTTON) {
    if (state == GLUT_DOWN) {
      moving = 1;
      startx = x;
      starty = y;
    }
    if (state == GLUT_UP) {
      moving = 0;
    }
  }
}


static void motion(int x, int y)
{
  if (moving) {
    angle = angle + (x - startx);
    angle2 = angle2 + (y - starty);
    startx = x;
    starty = y;
    glutPostRedisplay();
  }
}

void initRendering()
{
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
	glEnable(GL_NORMALIZE);
	//Enable smooth shading
	glShadeModel(GL_SMOOTH);
	// Enable Depth buffer
	glEnable(GL_DEPTH_TEST);
}

void setPoses(int frameNumber)
{
	shoulder = poses[frameNumber][0];
	arm = poses[frameNumber][1];
	elbow = poses[frameNumber][2];
	joint = poses[frameNumber][3];
	left_hip = poses[frameNumber][4];
	left_thigh = poses[frameNumber][5];
	left_leg = poses[frameNumber][6];
	right_hip = poses[frameNumber][7];
	right_thigh = poses[frameNumber][8];
	right_leg = poses[frameNumber][9];
	ball_position_y = poses[frameNumber][10];
	ball_position_z = poses[frameNumber][11];
	casquette_position_y = poses[frameNumber][12];
	step_forward = poses[frameNumber][13];
}

static int f = 0;
void timer( int value )
{
	f = f % 180;
	setPoses(f);
	f++;
	glutPostRedisplay();
	glutTimerFunc(3, timer, 0);
}

int main(int argc, char **argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); 
   glutInitWindowSize(900, 900);                 
   glutInitWindowPosition(600, 60);             
   glutCreateWindow(argv[0]);                   
   init();
   initRendering();
   glutMouseFunc(mouse);                        
   glutMotionFunc(motion);                        
   
   attachMenu();
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);                      
   glutKeyboardFunc(keyboard);                    
                                                  
   glutSpecialFunc(specialKeys);

   glutTimerFunc(0, timer, 0);
   glutMainLoop();
   return 0;
}